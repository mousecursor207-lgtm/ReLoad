Option Explicit
Dim shell, fso, folder, htaPath
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

folder = fso.GetParentFolderName(WScript.ScriptFullName)
htaPath = fso.BuildPath(folder, "ReLoad.hta")

If Not fso.FileExists(htaPath) Then
    MsgBox "ReLoad.hta was not found next to this script." & vbCrLf & _
           "Keep ReLoad.vbs and ReLoad.hta in the same folder.", _
           vbExclamation, "ReLoad!"
    WScript.Quit 1
End If

shell.Run """" & htaPath & """", 1, False
